package com.jediupc.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class EditorActivity extends AppCompatActivity {

    private LinearLayout parentLinearLayout;
    LinkedHashMap<String, Double> Evaluation = new LinkedHashMap<>();
    EditText mSubject;
    EditText mEvent;
    EditText mPercentage;
    String sEvent, sPercentage;
    Double dPercentage;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        parentLinearLayout = findViewById(R.id.show);
        mSubject = findViewById(R.id.name);
        mEvent = findViewById(R.id.name_edit_text);
        mPercentage = findViewById(R.id.percentage_edit_text);
    }

    public void onAddField(View v) {
        sEvent = mEvent.getText().toString();
        if(!Evaluation.containsKey(sEvent)) {
            sPercentage = mPercentage.getText().toString();
            dPercentage = Double.parseDouble(sPercentage);
            Evaluation.put(sEvent, dPercentage);
            String Message = sEvent + " (" + sPercentage + ")";
            TextView nEntry = new TextView(this);
            nEntry.setText(Message);
            parentLinearLayout.addView(nEntry);
        }
        else Log.d("Map", "Ya tengo ese evento, pon otro ! >:V");
    }

    public void onDelete(View v) {
        if (!Evaluation.isEmpty()) {
            Iterator<String> it = Evaluation.keySet().iterator();
            String lastKey = sEvent;
            while (it.hasNext()) {
                lastKey = it.next();
            }
            Log.d("Map", "La ultima key borrada es: "+lastKey);
            Evaluation.remove(lastKey);
            parentLinearLayout.removeViews(parentLinearLayout.getChildCount() - 1, 1);
        }
        else Log.d("Map","Estoy vacio !!!");
    }

    public void onFinish(View v) {
        if(!Evaluation.isEmpty()) {
            if(sumaUno(Evaluation)) Log.d("Map", "Mis valores son correctos !!!");
            else Log.d("Map", "Revisa lo que has escrito");
        }
        else Log.d("Map", "No se crean asignaturas vacias ! :-(");
    }

    public boolean sumaUno(LinkedHashMap<String,Double> map) {
        Iterator<String> it = map.keySet().iterator();
        Double suma = 0d;
        while(it.hasNext()) {
            String key = it.next();
            suma += map.get(key);
        }
        Log.d("sumaUno", String.valueOf(Math.round(suma)));
        if(Math.round(suma) == 1) return true;
        else return false;
    }
}

