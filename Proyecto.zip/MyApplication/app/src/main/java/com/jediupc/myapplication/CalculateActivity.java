package com.jediupc.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.LinkedHashMap;

public class CalculateActivity extends AppCompatActivity {

    private LinkedHashMap<String, Double> Marks = new LinkedHashMap<>();
    private String sEvent, sMark;
    private double dMark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        SubjectModel Method = (SubjectModel) getIntent().getSerializableExtra("ev_method");
        TextView show = findViewById(R.id.calcTitle);
        show.setText(Method.name);
    }

    public void onConfirm(View v){

    }
}
