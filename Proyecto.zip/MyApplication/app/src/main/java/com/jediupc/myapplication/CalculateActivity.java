package com.jediupc.myapplication;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class CalculateActivity extends AppCompatActivity {

    private EditText mMark;
    private TextView mEvent;
    private TextView mPercentage;
    private String sMark, sPercentage;
    private double dMark;
    private ArrayList<Double> Marks = new ArrayList<>();
    private ArrayList<String> Events = new ArrayList<>();
    private ArrayList<Double> Percentages = new ArrayList<>();
    private int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        SubjectModel Method = (SubjectModel) getIntent().getSerializableExtra("ev_method");
        mMark = findViewById(R.id.mark);
        mEvent = findViewById(R.id.eventTitle);
        mPercentage = findViewById(R.id.percentageView);
        TextView show = findViewById(R.id.calcTitle);
        show.setText(Method.name);
        copyData(Method.evalmethod);
        mEvent.setText(Events.get(index));
        sPercentage = "x("+String.valueOf(Percentages.get(index))+")";
        mPercentage.setText(sPercentage);
    }

    public void copyData(LinkedHashMap<String, Double> map){
        Iterator<String> it = map.keySet().iterator();
        while(it.hasNext()) {
            String key = it.next();
            Events.add(key);
            Percentages.add(map.get(key));
        }
    }

    public void storeMarks(int pos, double mark){
        Marks.add(pos, mark);
    }

    public void updateMarks(int pos, double mark) {
        Marks.set(pos, mark);
    }

    public void onConfirm(View v) {
        sMark = mMark.getText().toString();
        dMark = Double.parseDouble(sMark);
        if(Marks.size() == Events.size()) updateMarks(index, dMark);
        else storeMarks(index, dMark);
    }

    public void onNextEvent(View v){
        if(index < Events.size()) index++;
        if(index == Events.size()) index = 0;
        mEvent.setText(Events.get(index));
        sPercentage = "x("+String.valueOf(Percentages.get(index))+")";
        mPercentage.setText(sPercentage);
    }

    public void onPrevEvent(View v) {
        if(index > 0) index--;
        else if(index == 0) index = Events.size()-1;
        mEvent.setText(Events.get(index));
        sPercentage = "x("+String.valueOf(Percentages.get(index))+")";
        mPercentage.setText(sPercentage);
    }

    public void onCalculate(View v) {
        if(Marks.size() == Percentages.size()) {
            double finalmark = 0;
            for(int i = 0; i < Events.size(); i++)
                finalmark += (Marks.get(i)*Percentages.get(i));

            String sfinalmark = String.valueOf(finalmark);
            new AlertDialog.Builder(this)
                    .setTitle("Nota Final")
                    .setMessage(sfinalmark)
                    .setNeutralButton(android.R.string.ok, null)
                    .show();
        }
        else {
            new AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("Rellena todos los campos !")
                    .setNeutralButton(android.R.string.ok, null)
                    .show();
        }
    }
}

