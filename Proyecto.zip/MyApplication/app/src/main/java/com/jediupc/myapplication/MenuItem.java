package com.jediupc.myapplication;

public class MenuItem {
    public String title;
    public SubjectModel subj;
    public MenuItem(String title, SubjectModel subj) {
        this.title = title;
        this.subj = subj;
    }
}
