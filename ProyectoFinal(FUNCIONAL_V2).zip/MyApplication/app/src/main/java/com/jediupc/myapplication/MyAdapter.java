package com.jediupc.myapplication;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private final OnItemClickListener mListener;
    private ArrayList<SubjectModel> menulist;

    public interface OnItemClickListener {
        void onItemClick(View v, int pos);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public RelativeLayout mRoot;
        public TextView mTextView;

        public MyViewHolder(RelativeLayout v) {
            super(v);
            mRoot = v;
            mTextView = v.findViewById(R.id.tvTitle);
        }
    }

    public MyAdapter(ArrayList<SubjectModel> mmenulist, OnItemClickListener listener) {
        menulist = mmenulist;
        mListener = listener;
    }

    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        RelativeLayout v = (RelativeLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.my_text_view, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.mRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.onItemClick(view, position);
            }
        });
        holder.mTextView.setText(menulist.get(position).name);
    }

    @Override
    public int getItemCount() {
        return menulist.size();
    }
}
