package com.jediupc.myapplication;

import java.io.Serializable;
import java.util.LinkedHashMap;

public class SubjectModel implements Serializable {
    public String name;
    public LinkedHashMap<String, Double> evalmethod;

    public SubjectModel(String name, LinkedHashMap<String, Double> evalmethod) {
        this.name = name;
        this.evalmethod = evalmethod;
    }
}