package com.jediupc.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

public class EditorActivity extends AppCompatActivity implements View.OnClickListener{

    private LinearLayout parentLinearLayout;
    LinkedHashMap<String, Double> Evaluation = new LinkedHashMap<>();
    EditText mSubject;
    EditText mEvent;
    EditText mPercentage;
    String sEvent, sPercentage;
    Double dPercentage;
    Button bADD, bFINISH, bDELETE;
    public ModelContainer mModel = new ModelContainer();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        parentLinearLayout = findViewById(R.id.show);
        mSubject = findViewById(R.id.name);
        mEvent = findViewById(R.id.name_edit_text);
        mPercentage = findViewById(R.id.percentage_edit_text);
        bADD = findViewById(R.id.addButton);
        bFINISH = findViewById(R.id.finishButton);
        bDELETE = findViewById(R.id.deleteButton);
        bADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddField(v);
            }
        });
        bDELETE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDelete(v);
            }
        });
        bFINISH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFinish(v);
            }
        });


    }

    @Override
    protected void onPause() {
        super.onPause();
        mModel.save(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mModel = ModelContainer.load(this);
    }

    public void onAddField(View v) {
        sEvent = mEvent.getText().toString();
        if(!Evaluation.containsKey(sEvent)) {
            sPercentage = mPercentage.getText().toString();
            dPercentage = Double.parseDouble(sPercentage);
            Evaluation.put(sEvent, dPercentage);
            String Message = sEvent + " (" + sPercentage + ")";
            TextView nEntry = new TextView(this);
            nEntry.setText(Message);
            nEntry.setTextSize(25);
            parentLinearLayout.addView(nEntry);
        }
        else Log.d("Map", "Ya tengo ese evento, pon otro !");
    }

    public void onDelete(View v) {
        if (!Evaluation.isEmpty()) {
            Iterator<String> it = Evaluation.keySet().iterator();
            String lastKey = sEvent;
            while (it.hasNext()) {
                lastKey = it.next();
            }
            Log.d("Map", "La ultima key borrada es: "+lastKey);
            Evaluation.remove(lastKey);
            parentLinearLayout.removeViews(parentLinearLayout.getChildCount() - 1, 1);
        }
        else Log.d("Map","Estoy vacio !!!");
    }

    public void onFinish(View v) {
        if(!Evaluation.isEmpty()) {
            if(sumaUno(Evaluation)){
                Log.d("Map", "Mis valores son correctos !!!");
                String sSubject = mSubject.getText().toString();
                SubjectModel Subject = new SubjectModel(sSubject, Evaluation);
                mModel.menulist.add(Subject);
                finish();
            }
            else Log.d("Map", "Revisa lo que has escrito");
        }
        else Log.d("Map", "No se crean asignaturas vacias !");
    }

    public boolean sumaUno(LinkedHashMap<String,Double> map) {
        Iterator<String> it = map.keySet().iterator();
        Double suma = 0d;
        while(it.hasNext()) {
            String key = it.next();
            suma += map.get(key);
        }
        Log.d("sumaUno", String.valueOf(Math.round(suma)));
        if(Math.round(suma) == 1) return true;
        else return false;
    }

    @Override
    public void onClick(View v) {
    }
}

