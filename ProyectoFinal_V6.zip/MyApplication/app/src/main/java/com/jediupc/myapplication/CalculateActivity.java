package com.jediupc.myapplication;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class CalculateActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mMark;
    private TextView mEvent;
    private TextView mPercentage;
    private String sMark, sPercentage;
    private float dMark;
    private ArrayList<Float> Marks = new ArrayList<>();
    private ArrayList<String> Events = new ArrayList<>();
    private ArrayList<Float> Percentages = new ArrayList<>();
    private int index = 0;
    Button bNEXT, bPREV, bCONF, bCALC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        SubjectModel Method = (SubjectModel) getIntent().getSerializableExtra("ev_method");
        mMark = findViewById(R.id.mark);
        mEvent = findViewById(R.id.eventTitle);
        mPercentage = findViewById(R.id.percentageView);
        TextView show = findViewById(R.id.calcTitle);
        show.setText(Method.name);
        copyData(Method.evalmethod);
        mEvent.setText(Events.get(index));
        sPercentage = "x("+String.valueOf(Percentages.get(index))+")";
        mPercentage.setText(sPercentage);
        bNEXT = findViewById(R.id.nextEvent);
        bPREV = findViewById(R.id.prevEvent);
        bCONF = findViewById(R.id.confirm);
        bCALC = findViewById(R.id.calculate);

        bNEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onNextEvent(v);
            }
        });

        bPREV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPrevEvent(v);
            }
        });

        bCONF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onConfirm(v);
            }
        });

        bCALC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCalculate(v);
            }
        });
    }

    public void copyData(LinkedHashMap<String, Float> map){
        Iterator<String> it = map.keySet().iterator();
        while(it.hasNext()) {
            String key = it.next();
            Events.add(key);
            Percentages.add(map.get(key));
        }
    }

    public void storeMarks(int pos, float mark){
        Marks.add(pos, mark);
    }

    public void updateMarks(int pos, float mark) {
        Marks.set(pos, mark);
    }

    public void onConfirm(View v) {
        sMark = mMark.getText().toString();
        dMark = Float.parseFloat(sMark);
        if(Marks.size() == Events.size()) updateMarks(index, dMark);
        else storeMarks(index, dMark);
    }

    public void onNextEvent(View v){
        if(index < Events.size()) index++;
        if(index == Events.size()) index = 0;
        mEvent.setText(Events.get(index));
        sPercentage = "x("+String.valueOf(Percentages.get(index))+")";
        mPercentage.setText(sPercentage);
    }

    public void onPrevEvent(View v) {
        if(index > 0) index--;
        else if(index == 0) index = Events.size()-1;
        mEvent.setText(Events.get(index));
        sPercentage = "x("+String.valueOf(Percentages.get(index))+")";
        mPercentage.setText(sPercentage);
    }

    public void onCalculate(View v) {
        if(Marks.size() == Percentages.size()) {
            float finalmark = 0;
            for(int i = 0; i < Events.size(); i++)
                finalmark += (Marks.get(i)*Percentages.get(i));

            String sfinalmark = String.valueOf(finalmark);
            new AlertDialog.Builder(this)
                    .setTitle("Nota Final")
                    .setMessage(sfinalmark)
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
        }
        else {
            new AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("Rellena todos los campos !")
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
        }
    }

    @Override
    public void onClick(View v) {}
}

